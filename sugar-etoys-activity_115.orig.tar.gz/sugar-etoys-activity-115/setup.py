#!/usr/bin/env python
from sugar.activity import bundlebuilder
bundlebuilder.start()
